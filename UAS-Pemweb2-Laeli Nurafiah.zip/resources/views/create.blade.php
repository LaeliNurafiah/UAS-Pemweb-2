<div class="p2">
    <div class="form-group mb-3">
        <input type="text" name="no_polisi" id="no_polisi" class="form-control "placeholder="Nomor Polisi..." required autocomplete="off">
    </div>
    <div class="form-group mb-3">
        <input type="text" name="merk" id="merk" class="form-control " placeholder="Merk..." required autocomplete="off">
    </div>
    <div class="input-group mt-3">
        <select class="form-select" id="tipe" name="tipe" >
          <option value="Sepeda Motor">Sepeda Motor</option>
          <option value="Mobil">Mobil</option>
        </select>
      </div>
    <div class="form-group mt-5">
    <button class="btn btn-dark" onclick="store()">Tambah Data</button>
    </div>
</div>
