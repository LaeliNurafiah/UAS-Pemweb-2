<table class="table">

    <thead>
        <tr>

            <th scope="col">No</th>
            <th scope="col">No.Polisi</th>
            <th scope="col">Merk Kendaraan</th>
            <th scope="col">Tipe Kendaraan</th>
            <th scope="col">Action</th>
        </tr>
    </thead>
    <tbody>
     @foreach ($vehicles as $vehicle)
            <tr>
              <td>{{ $loop->iteration }}</td>
              <td>{{ $vehicle->no_polisi }}</td>
              <td>{{ $vehicle->merk }}</td>
              <td>{{ $vehicle->tipe }}</td>
              <td>
                  <button class="btn btn-warning" onclick="show({{ $vehicle->id }})">Update</button>
                  <button class="btn btn-danger" onclick="destroy({{ $vehicle->id }})">Delete</button>
              </td>
            </tr>
              @endforeach
    </tbody>
</table>
