<?php

use App\Http\Controllers\VehicleController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });
Route::get('/', [VehicleController::class, 'index']);
Route::get('/read', [VehicleController::class, 'read']);
Route::get('/create', [VehicleController::class, 'create']);
Route::get('/store', [VehicleController::class, 'store']);
Route::get('/show/{id}', [VehicleController::class, 'show']);
Route::get('/update/{id}', [VehicleController::class, 'update']);
Route::get('/destroy/{id}', [VehicleController::class, 'destroy']);
