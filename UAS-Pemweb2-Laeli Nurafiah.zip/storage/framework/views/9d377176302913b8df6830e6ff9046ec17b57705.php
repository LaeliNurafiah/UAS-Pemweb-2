<div class="p2">
    <div class="form-group mb-3">
        <input type="text" name="no_polisi" id="no_polisi" class="form-control "placeholder="Nomor Polisi..." required value="<?php echo e($vehicle->no_polisi); ?>" autocomplete="off">
    </div>
    <div class="form-group mb-3">
        <input type="text" name="merk" id="merk" class="form-control " placeholder="Merk..." required value="<?php echo e($vehicle->merk); ?>" autocomplete="off" >
    </div>
    <div class="input-group mt-3">
        <select class="form-select" id="tipe" name="tipe" >
            <?php if($vehicle->tipe == 'Sepeda Motor'): ?>
    <option selected value="<?php echo e($vehicle->tipe); ?>"><?php echo e($vehicle->tipe); ?></option>
          <option value="Mobil">Mobil</option>
          <?php else: ?>
          <option value="Sepeda Motor">Sepeda Motor</option>
          <option selected value="<?php echo e($vehicle->tipe); ?>"><?php echo e($vehicle->tipe); ?></option>
          <?php endif; ?>
        </select>
      </div>
    <div class="form-group mt-5">
    <button class="btn btn-dark" onclick="update(<?php echo e($vehicle->id); ?>)">Update Data</button>
    </div>
</div>
<?php /**PATH D:\Laravel\uas_pemweb2\resources\views/update.blade.php ENDPATH**/ ?>