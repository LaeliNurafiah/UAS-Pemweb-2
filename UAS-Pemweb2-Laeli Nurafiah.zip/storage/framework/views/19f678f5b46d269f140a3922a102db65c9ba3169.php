<table class="table">

    <thead>
        <tr>

            <th scope="col">No</th>
            <th scope="col">No.Polisi</th>
            <th scope="col">Merk Kendaraan</th>
            <th scope="col">Tipe Kendaraan</th>
            <th scope="col">Action</th>
        </tr>
    </thead>
    <tbody>
     <?php $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($loop->iteration); ?></td>
              <td><?php echo e($vehicle->no_polisi); ?></td>
              <td><?php echo e($vehicle->merk); ?></td>
              <td><?php echo e($vehicle->tipe); ?></td>
              <td>
                  <button class="btn btn-warning" onclick="show(<?php echo e($vehicle->id); ?>)">Update</button>
                  <button class="btn btn-danger" onclick="destroy(<?php echo e($vehicle->id); ?>)">Delete</button>
              </td>
            </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH D:\Laravel\uas_pemweb2\resources\views/read.blade.php ENDPATH**/ ?>